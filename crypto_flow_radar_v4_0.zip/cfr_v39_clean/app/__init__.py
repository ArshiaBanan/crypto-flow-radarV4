"""Crypto Flow Radar package."""
